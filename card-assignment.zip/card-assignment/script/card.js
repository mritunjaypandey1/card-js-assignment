// API CODE STARTS HERE
var userinfo = document.querySelectorAll('.user-info ');
(async function fetchImg() {
   for(i=0;i<userinfo.length;i++){

      let cardInfo = await fetch('https://randomuser.me/api/'); // API URL
      if (cardInfo.ok) {
            let json = await cardInfo.json(); // API Response OBject
            let results = json.results[0]
            userinfo[i].querySelector('.image').src = results.picture.large; // GET Pictures
            userinfo[i].querySelector('.username').innerHTML += results.name.first + ' ' + results.name.last; // GET First And Last Name
            userinfo[i].querySelector('.email').innerHTML += results.email; // GET Email
            userinfo[i].querySelector('.dob').innerHTML += results.dob.date; // GET Date Of Birth 
            userinfo[i].querySelector('.address').innerHTML += results.location.street.number; // GET Location
            userinfo[i].querySelector('.contact').innerHTML += results.cell; // GET Contact
            userinfo[i].querySelector('.password').innerHTML += results.login.password; // GET Password
         } 
      else {
         console.error("HTTP-Error: " + cardInfo.status);
      }
   }
})();
